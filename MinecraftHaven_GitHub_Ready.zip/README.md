# MinecraftHaven — GitHub Pages Ready

This is a lightweight static version of MinecraftHaven.

## Open locally
Extract the ZIP and double-click `index.html`. It opens directly in a normal browser.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, `script.js` and `README.md`.
3. Open the repository's **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Choose `main` and `/ (root)`.
6. Save.

No Node.js, database or API key is required for this version.

## Important
The database/add-on/news content is demo/sample content. Connect verified data and any AI/API service through a secure backend later.

Minecraft is a trademark of Mojang Studios. MinecraftHaven is an unofficial fan project and is not affiliated with or endorsed by Mojang or Microsoft.
