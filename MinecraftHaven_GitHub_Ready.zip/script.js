const data=[
["Blocks","Stone, ores and building blocks."],["Items","Tools, food and materials."],["Mobs","Hostile, passive and neutral mobs."],
["Biomes","Overworld, Nether and End environments."],["Commands","Useful Minecraft commands."],["Crafting","Recipes and crafting basics."],
["Enchantments","Enchantments and gear."],["Potions","Brewing and potion effects."],["Redstone","Machines and farms."]
];
document.getElementById("cards").innerHTML=data.map(x=>`<a class="card" href="#guides" style="text-decoration:none;color:inherit"><small>DATABASE</small><h3>${x[0]}</h3><p>${x[1]}</p></a>`).join("");
function doSearch(){let q=document.getElementById("search").value.toLowerCase().trim(),r=document.getElementById("results");if(!q){r.innerHTML="";return}let h=data.filter(x=>(x[0]+" "+x[1]).toLowerCase().includes(q));r.innerHTML=h.length?h.map(x=>`<div class="result"><b>${x[0]}</b> — ${x[1]}</div>`).join(""):`<div class="result">No demo result found.</div>`}
document.getElementById("search").addEventListener("input",doSearch);
function calcStacks(){let n=Math.max(0,Number(document.getElementById("amount").value)||0);document.getElementById("stackOut").textContent=`${Math.floor(n/64)} stack(s) + ${n%64} item(s).`}
function levelHelp(){let n=Number(document.getElementById("level").value)||0;document.getElementById("levelOut").textContent=n?`Target level: ${n}.`:"Enter a level first."}
document.getElementById("menuBtn").onclick=()=>document.getElementById("nav").classList.toggle("open");
